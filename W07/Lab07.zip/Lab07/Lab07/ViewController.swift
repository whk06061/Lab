//
//  ViewController.swift
//  Lab07
//
//  Created by Mac SWU on 2020/04/28.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

