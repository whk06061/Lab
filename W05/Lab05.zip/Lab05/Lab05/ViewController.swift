//
//  ViewController.swift
//  Lab05
//
//  Created by Mac SWU on 2020/04/13.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    
    @IBOutlet var buttonNewYear: UIButton!
    @IBOutlet var buttonMemorial: UIButton!
    @IBOutlet var buttonIndependence: UIButton!
    @IBOutlet var buttonChristmas: UIButton!
    
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var pickerView: UIPickerView!
    @IBOutlet var hiddenView: UIView!
    
    let yearMonthArray: Array<String> = ["1월 1일", "6월 6일", "8월 15일", "12월 25일"]
    var started: Bool!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        started = false
        hiddenView.isHidden = true
        
    }
    
   
       
    @IBAction func buttonStart(_ sender: UIButton) {
        
        started = true
        hiddenView.isHidden = started
        activityIndicator.startAnimating()
        
    }
    
    @IBAction func buttonHoliday(_ sender: UIButton) {
        
        let index = pickerView.selectedRow(inComponent: 0)
        
        if(started)
        {
            if((sender.titleLabel?.text == "새  해" && yearMonthArray[index] == "1월 1일") || (sender.titleLabel?.text == "현충일" && yearMonthArray[index] == "6월 6일") || (sender.titleLabel?.text == "광복절" && yearMonthArray[index] == "8월 15일") || (sender.titleLabel?.text == "성탄절" && yearMonthArray[index] == "12월 25일") )
            {
                hiddenView.isHidden = !started
                activityIndicator.stopAnimating()
                started = false
            }
            
        }

    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return yearMonthArray.count
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return yearMonthArray[row]
        
    }
 
}

