//
//  SegControlViewController.swift
//  Lab04
//
//  Created by Mac SWU on 2020/04/06.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class SegControlViewController: UIViewController {

    @IBOutlet var leftRightSegControl: UISegmentedControl!
    @IBOutlet var displayLabel: UILabel!
    var selectedSegmentIndex: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        var makeString=leftRightSegControl.titleForSegment(at: selectedSegmentIndex)!
        leftRightSegControl.selectedSegmentIndex=selectedSegmentIndex
        displayLabel.text=makeString+" 선택됨"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
