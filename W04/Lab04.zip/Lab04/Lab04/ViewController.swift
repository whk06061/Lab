//
//  ViewController.swift
//  Lab04
//
//  Created by Mac SWU on 2020/04/06.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var onOffSwitch: UISwitch!
    @IBOutlet var leftRightSegControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier=="toSwitchView"{
            let destVC = segue.destination as! SwitchViewController
            
            destVC.onOffStatus=true
            
            if !onOffSwitch.isOn{
                destVC.onOffStatus=false
            }
            
        }else if segue.identifier=="toSegControlView"{
            let destVC = segue.destination as! SegControlViewController
            
            destVC.selectedSegmentIndex=0
            
            if leftRightSegControl.selectedSegmentIndex==1{
                destVC.selectedSegmentIndex=1
            }
        }
    }


}

