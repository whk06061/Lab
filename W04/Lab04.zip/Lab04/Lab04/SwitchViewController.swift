//
//  SwitchViewController.swift
//  Lab04
//
//  Created by Mac SWU on 2020/04/06.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class SwitchViewController: UIViewController {

    @IBOutlet var onOffSwitch: UISwitch!
    @IBOutlet var displayLabel: UILabel!
    var onOffStatus : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        onOffSwitch.isOn = onOffStatus
        if onOffStatus{
            displayLabel.text="Switch is ON"
        }
        else{
            displayLabel.text="Switch is OFF"
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
