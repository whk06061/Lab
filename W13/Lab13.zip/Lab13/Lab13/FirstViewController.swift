//
//  FirstViewController.swift
//  Lab13
//
//  Created by Mac SWU on 2020/06/17.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func addCoffee() {
        let coffeeString = "커피 하나 추가요~"
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.coffee.append(coffeeString)
        
        let sceneDelegate = UIApplication.shared.connectedScenes.first!.delegate as! SceneDelegate
        let tabController = sceneDelegate.window?.rootViewController as! UITabBarController
        let secondVC = tabController.children[1] as! SecondTableViewController
        secondVC.coffeeTab.badgeValue = String(format: "%d", appDelegate.coffee.count)
    }
    
    @IBAction func addCocktail() {
        let cocktailString = "칵테일 하나 추가요!!"
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.cocktail.append(cocktailString)
        
        let sceneDelegate = UIApplication.shared.connectedScenes.first!.delegate as! SceneDelegate
        let tabController = sceneDelegate.window?.rootViewController as! UITabBarController
        let thirdVC = tabController.children[2] as! ThirdTableViewController
        thirdVC.cocktailTab.badgeValue = String(format: "%d", appDelegate.cocktail.count)
    }
}

