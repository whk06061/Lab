//
//  ViewController.swift
//  Lab11
//
//  Created by Mac SWU on 2020/06/04.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet var picker: UIPickerView!
    @IBOutlet var labelResult: UILabel!
    
    var monthArray: [String] = Array()
    var dayArray: [String] = Array()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        for i in 1...12{monthArray.append("\(i)")}
        for i in 1...31{dayArray.append("\(i)")}
    }

    @IBAction func whatDay() {
        let month = monthArray[self.picker.selectedRow(inComponent: 0)]
        let day = dayArray[self.picker.selectedRow(inComponent: 1)]
        let urlString: String = "http://condi.swu.ac.kr/student/labs/findWhatDay.php"
        guard let requestURL = URL(string: urlString) else{
            return
        }
        var request = URLRequest(url: requestURL)
        request.httpMethod = "POST"
        let restString: String = "month=" + month + "&day=" + day
        request.httpBody = restString.data(using: .utf8)
        
        let session = URLSession.shared
        let task = session.dataTask(with: request){
            (responseData, response, responseError) in
            guard responseError == nil else {print("Error: calling POST")
                return }
            
            guard let receivedData = responseData else{
                print("Error: not receiving Data")
                return }
            
            let response = response as! HTTPURLResponse
                if !(200...299 ~= response.statusCode){
                    print("HTTP Error!")
                    return }
            
                if let utf8Data = String(data: receivedData, encoding: .utf8){
                        DispatchQueue.main.sync {
                            self.labelResult.text = utf8Data } }
                else{
                    self.labelResult.text = ""
                    }
        }
        task.resume()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return monthArray.count
        }else{
            return dayArray.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return monthArray[row]
        }else{
            return dayArray[row]
        }
    }
    

}

