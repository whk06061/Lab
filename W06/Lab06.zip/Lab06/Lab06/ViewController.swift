//
//  ViewController.swift
//  Lab06
//
//  Created by Mac SWU on 2020/04/20.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

