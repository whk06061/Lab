//
//  CountWord.swift
//  Lab06Tests
//
//  Created by Mac SWU on 2020/04/20.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import Foundation
class CountWord{
    class func convert (words: String) -> [String: Int]{
        var returnValue:[String: Int]! = [String: Int]()

        for kWord in words.components(separatedBy: " "){
            let cWord = kWord.lowercased()
            
           if let value = returnValue[cWord]{
                returnValue[cWord] = value + 1
            } else{
                returnValue[cWord] = 1
            }
        }
        return returnValue
    }
}
