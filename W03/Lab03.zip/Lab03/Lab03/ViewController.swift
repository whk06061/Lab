//
//  ViewController.swift
//  Lab03
//
//  Created by Mac SWU on 2020/03/30.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate{

    
    @IBOutlet var displayLabel: UILabel!
    @IBOutlet var myTextField: UITextField!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func buttonDisplay() {
        displayLabel.text=myTextField.text!
    }
    
    @IBAction func segControlDisplay(_ sender: UISegmentedControl) {
    displayLabel.text=sender.titleForSegment(at: sender.selectedSegmentIndex)
    }
    
    @IBAction func switchDisplay(_ sender: UISwitch) {
        if sender.isOn{
            displayLabel.text="Switch is On"
        }else{
            displayLabel.text="Switch is Off"
        }
    }
    
    @IBAction func sliderDisplay(_ sender: UISlider) {
        displayLabel.text=String(format:"%10.8f",sender.value)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

