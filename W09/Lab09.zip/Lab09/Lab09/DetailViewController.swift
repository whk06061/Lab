//
//  DetailViewController.swift
//  Lab09
//
//  Created by Mac SWU on 2020/05/23.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    @IBOutlet var textTitle: UITextField!
    @IBOutlet var textContent: UITextView!
    @IBOutlet var saveDate: UILabel!
    
    var detailIdea: NSManagedObject?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let idea = detailIdea{
            textTitle.text = idea.value(forKey: "ideaTitle") as? String
            textContent.text = idea.value(forKey: "ideaContent") as? String
            let dbDate: Date? = idea.value(forKey: "ideaDate") as? Date
            let formatter: DateFormatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd h:mm a"
            if let unwrapDate = dbDate{
                saveDate.text = formatter.string(from: unwrapDate as Date) + " 저장됨"
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
