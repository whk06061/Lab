//
//  ViewController.swift
//  Lab08
//
//  Created by Mac SWU on 2020/05/12.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    let size: Int = 4
    var lottoArrays = Array<Array<Int>>() /*2차원 배열*/
    var originalNumbers = Array(1 ... 45)
    
    @IBOutlet var lottoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func doDraw(_ sender: UIBarButtonItem) {
        var index = 0
        var originalNumbersCopy = Array<Int>()  /*originalNumbers를 복사한 변수 originalNumbersCopy*/
        var lottoArray = Array<Int>()           /*2차원배열의 원소 배열인 lottoArray*/
        lottoArrays.removeAll()
        
        for _ in 0...size-1{
            
            originalNumbersCopy = originalNumbers
            lottoArray.removeAll()
            
            for _ in 0...5{
                index=Int(arc4random_uniform(UInt32(originalNumbersCopy.count)))
                lottoArray.append(originalNumbersCopy[index])
                originalNumbersCopy.remove(at: index)
                lottoArray.sort(by: {$0 < $1})
            }
            lottoArrays.append(lottoArray)
        }
        lottoTableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lottoArrays.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = self.lottoTableView.dequeueReusableCell(withIdentifier: "Lotto Cell", for: indexPath) as! LottoCell
        
        cell.number1.text = String(lottoArrays[indexPath.row][0])
        cell.number2.text = String(lottoArrays[indexPath.row][1])
        cell.number3.text = String(lottoArrays[indexPath.row][2])
        cell.number4.text = String(lottoArrays[indexPath.row][3])
        cell.number5.text = String(lottoArrays[indexPath.row][4])
        cell.number6.text = String(lottoArrays[indexPath.row][5])
        
        return cell
    }

}

