//
//  LottoCell.swift
//  Lab08
//
//  Created by Mac SWU on 2020/05/12.
//  Copyright © 2020 Mac SWU. All rights reserved.
//

import UIKit

class LottoCell: UITableViewCell {

    @IBOutlet var number1: UILabel!
    @IBOutlet var number2: UILabel!
    @IBOutlet var number3: UILabel!
    @IBOutlet var number4: UILabel!
    @IBOutlet var number5: UILabel!
    @IBOutlet var number6: UILabel!

}
